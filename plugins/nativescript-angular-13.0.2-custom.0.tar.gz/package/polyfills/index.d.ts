export declare const nsNgPolyfills = true;
