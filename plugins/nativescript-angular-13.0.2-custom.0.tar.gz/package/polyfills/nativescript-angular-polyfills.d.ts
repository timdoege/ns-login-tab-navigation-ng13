/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@nativescript/angular/polyfills" />
export * from './index';
