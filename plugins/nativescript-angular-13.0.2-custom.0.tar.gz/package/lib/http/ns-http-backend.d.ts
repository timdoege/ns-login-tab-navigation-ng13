import { HttpRequest, HttpEvent, HttpXhrBackend } from '@angular/common/http';
import { XhrFactory } from '@angular/common';
import { Observable } from 'rxjs';
import { NSFileSystem } from '../file-system/ns-file-system';
import * as i0 from "@angular/core";
export declare class NsHttpBackEnd extends HttpXhrBackend {
    private nsFileSystem;
    constructor(xhrFactory: XhrFactory, nsFileSystem: NSFileSystem);
    handle(req: HttpRequest<any>): Observable<HttpEvent<any>>;
    private handleLocalFileRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<NsHttpBackEnd, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NsHttpBackEnd>;
}
