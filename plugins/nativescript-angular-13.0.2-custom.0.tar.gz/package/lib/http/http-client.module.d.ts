import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
export declare class NativeScriptHttpClientModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptHttpClientModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeScriptHttpClientModule, never, [typeof i1.HttpClientModule], [typeof i1.HttpClientModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeScriptHttpClientModule>;
}
