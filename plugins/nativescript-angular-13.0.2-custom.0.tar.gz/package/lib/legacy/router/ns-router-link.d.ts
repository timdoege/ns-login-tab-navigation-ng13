import { ElementRef, NgZone, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router, UrlTree } from '@angular/router';
import { NavigationTransition } from '@nativescript/core';
import { RouterExtensions } from './router-extensions';
import * as i0 from "@angular/core";
export declare type QueryParamsHandling = 'merge' | 'preserve' | '';
/**
 * The nsRouterLink directive lets you link to specific parts of your app.
 *
 * Consider the following route configuration:
 * ```
 * [{ path: "/user", component: UserCmp }]
 * ```
 *
 * When linking to this `User` route, you can write:
 *
 * ```
 * <a [nsRouterLink]="["/user"]">link to user component</a>
 * ```
 *
 * NSRouterLink expects the value to be an array of path segments, followed by the params
 * for that level of routing. For instance `["/team", {teamId: 1}, "user", {userId: 2}]`
 * means that we want to generate a link to `/team;teamId=1/user;userId=2`.
 *
 * The first segment name can be prepended with `/`, `./`, or `../`.
 * If the segment begins with `/`, the router will look up the route from the root of the app.
 * If the segment begins with `./`, or doesn"t begin with a slash, the router will
 * instead look in the current component"s children for the route.
 * And if the segment begins with `../`, the router will go up one level.
 */
export declare class NSRouterLink implements AfterViewInit {
    private ngZone;
    private router;
    private navigator;
    private route;
    private el;
    target: string;
    queryParams: {
        [k: string]: any;
    };
    fragment: string;
    queryParamsHandling: QueryParamsHandling;
    preserveQueryParams: boolean;
    preserveFragment: boolean;
    skipLocationChange: boolean;
    replaceUrl: boolean;
    clearHistory: boolean;
    pageTransition: boolean | string | NavigationTransition;
    pageTransitionDuration: any;
    private commands;
    constructor(ngZone: NgZone, router: Router, navigator: RouterExtensions, route: ActivatedRoute, el: ElementRef);
    ngAfterViewInit(): void;
    set params(data: any[] | string);
    onTap(): void;
    private getExtras;
    get urlTree(): UrlTree;
    private convertClearHistory;
    private getTransition;
    static ɵfac: i0.ɵɵFactoryDeclaration<NSRouterLink, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NSRouterLink, "[nsRouterLink]", never, { "target": "target"; "queryParams": "queryParams"; "fragment": "fragment"; "queryParamsHandling": "queryParamsHandling"; "preserveQueryParams": "preserveQueryParams"; "preserveFragment": "preserveFragment"; "skipLocationChange": "skipLocationChange"; "replaceUrl": "replaceUrl"; "clearHistory": "clearHistory"; "pageTransition": "pageTransition"; "pageTransitionDuration": "pageTransitionDuration"; "params": "nsRouterLink"; }, {}, never>;
}
