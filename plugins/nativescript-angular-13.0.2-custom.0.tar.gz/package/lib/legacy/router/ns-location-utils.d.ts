import { Frame, NavigationTransition } from '@nativescript/core';
import { UrlSegmentGroup, Params } from '@angular/router';
export interface LocationState {
    queryParams: Params;
    segmentGroup: UrlSegmentGroup;
    isRootSegmentGroup: boolean;
    isPageNavigation: boolean;
    frame?: Frame;
}
export interface NavigationOptions {
    clearHistory?: boolean;
    animated?: boolean;
    transition?: NavigationTransition;
}
export declare class Outlet {
    showingModal: boolean;
    modalNavigationDepth: number;
    parent: Outlet;
    _navigatingBackOutlets: Set<string>;
    get isPageNavigationBack(): boolean;
    set isPageNavigationBack(isBack: boolean);
    outletKeys: Array<string>;
    frames: Array<Frame>;
    path: string;
    pathByOutlets: string;
    states: Array<LocationState>;
    isNSEmptyOutlet: boolean;
    shouldDetach: boolean;
    constructor(outletKey: string, path: string, pathByOutlets: string, modalNavigationDepth?: number);
    setOutletKeyNavigatingBack(key: string): void;
    containsFrame(frame: Frame): boolean;
    peekState(): LocationState;
    containsTopState(stateUrl: string): boolean;
    getFrameToBack(): Frame;
}
export declare const defaultNavOptions: NavigationOptions;
