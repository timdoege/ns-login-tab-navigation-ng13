import { ChangeDetectorRef, ComponentFactoryResolver, ComponentRef, InjectionToken, Injector, OnDestroy, EventEmitter, Type, ViewContainerRef, ElementRef, InjectFlags, NgZone } from '@angular/core';
import { ActivatedRoute, ChildrenOutletContexts } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { PageFactory } from '../../tokens';
import { ViewUtil } from '../../view-util';
import { NSLocationStrategy } from './ns-location-strategy';
import { NSRouteReuseStrategy } from './ns-route-reuse-strategy';
import * as i0 from "@angular/core";
export declare class PageRoute {
    activatedRoute: BehaviorSubject<ActivatedRoute>;
    constructor(startRoute: ActivatedRoute);
}
export declare class DestructibleInjector implements Injector {
    private destructableProviders;
    private parent;
    private refs;
    constructor(destructableProviders: ProviderSet, parent: Injector);
    get<T>(token: Type<T> | InjectionToken<T>, notFoundValue?: T, flags?: InjectFlags): T;
    destroy(): void;
}
declare type ProviderSet = Set<Type<any> | InjectionToken<any>>;
export declare class PageRouterOutlet implements OnDestroy {
    private parentContexts;
    private location;
    private locationStrategy;
    private componentFactoryResolver;
    private resolver;
    private changeDetector;
    private pageFactory;
    private routeReuseStrategy;
    private ngZone;
    private activated;
    private _activatedRoute;
    private detachedLoaderFactory;
    private outlet;
    private name;
    private isEmptyOutlet;
    private viewUtil;
    private frame;
    activateEvents: EventEmitter<any>;
    deactivateEvents: EventEmitter<any>;
    /** @deprecated from Angular since v4 */
    get locationInjector(): Injector;
    /** @deprecated from Angular since v4 */
    get locationFactoryResolver(): ComponentFactoryResolver;
    get isActivated(): boolean;
    get component(): unknown;
    get activatedRoute(): ActivatedRoute;
    constructor(parentContexts: ChildrenOutletContexts, location: ViewContainerRef, name: string, actionBarVisibility: string, isEmptyOutlet: boolean, locationStrategy: NSLocationStrategy, componentFactoryResolver: ComponentFactoryResolver, resolver: ComponentFactoryResolver, changeDetector: ChangeDetectorRef, pageFactory: PageFactory, routeReuseStrategy: NSRouteReuseStrategy, ngZone: NgZone, elRef: ElementRef, viewUtil: ViewUtil);
    setActionBarVisibility(actionBarVisibility: string): void;
    ngOnDestroy(): void;
    deactivate(): void;
    /**
     * Called when the `RouteReuseStrategy` instructs to detach the subtree
     */
    detach(): ComponentRef<any>;
    /**
     * Called when the `RouteReuseStrategy` instructs to re-attach a previously detached subtree
     */
    attach(ref: ComponentRef<any>, activatedRoute: ActivatedRoute): void;
    /**
     * Called by the Router to instantiate a new component during the commit phase of a navigation.
     * This method in turn is responsible for calling the `routerOnActivate` hook of its child.
     */
    activateWith(activatedRoute: ActivatedRoute, resolver: ComponentFactoryResolver | null): void;
    private activateOnGoForward;
    private loadComponentInPage;
    private markActivatedRoute;
    private getComponentFactory;
    private getOutlet;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageRouterOutlet, [null, null, { attribute: "name"; }, { attribute: "actionBarVisibility"; }, { attribute: "isEmptyOutlet"; }, null, null, null, null, null, null, null, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PageRouterOutlet, "page-router-outlet", never, {}, { "activateEvents": "activate"; "deactivateEvents": "deactivate"; }, never>;
}
export {};
