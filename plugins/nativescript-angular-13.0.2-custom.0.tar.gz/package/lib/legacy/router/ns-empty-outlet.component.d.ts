import { Page } from '@nativescript/core';
import { PageRouterOutlet } from './page-router-outlet';
import * as i0 from "@angular/core";
export declare class NSEmptyOutletComponent {
    private page;
    pageRouterOutlet: PageRouterOutlet;
    constructor(page: Page);
    static ɵfac: i0.ɵɵFactoryDeclaration<NSEmptyOutletComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NSEmptyOutletComponent, "ns-empty-outlet", never, {}, {}, never, never>;
}
