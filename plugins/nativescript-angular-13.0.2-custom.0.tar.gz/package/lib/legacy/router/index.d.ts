export { NSLocationStrategy } from './ns-location-strategy';
export { NSRouteReuseStrategy } from './ns-route-reuse-strategy';
export * from './router.module';
