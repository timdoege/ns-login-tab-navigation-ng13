import { ModuleWithProviders } from '@angular/core';
import { Routes, ExtraOptions } from '@angular/router';
import { NSLocationStrategy } from './ns-location-strategy';
import { FrameService } from '../frame.service';
import * as i0 from "@angular/core";
import * as i1 from "./ns-router-link";
import * as i2 from "./ns-router-link-active";
import * as i3 from "./page-router-outlet";
import * as i4 from "./ns-empty-outlet.component";
import * as i5 from "@angular/router";
import * as i6 from "../../nativescript-common.module";
export { PageRoute } from './page-router-outlet';
export { RouterExtensions } from './router-extensions';
export { Outlet, NavigationOptions, LocationState, defaultNavOptions } from './ns-location-utils';
export { NSRouterLink } from './ns-router-link';
export { NSRouterLinkActive } from './ns-router-link-active';
export { PageRouterOutlet } from './page-router-outlet';
export { NSLocationStrategy } from './ns-location-strategy';
export { NSEmptyOutletComponent } from './ns-empty-outlet.component';
export declare function provideLocationStrategy(locationStrategy: NSLocationStrategy, frameService: FrameService, startPath: string): NSLocationStrategy;
export declare class NativeScriptRouterModule {
    static forRoot(routes: Routes, config?: ExtraOptions): ModuleWithProviders<NativeScriptRouterModule>;
    static forChild(routes: Routes): ModuleWithProviders<NativeScriptRouterModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptRouterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeScriptRouterModule, [typeof i1.NSRouterLink, typeof i2.NSRouterLinkActive, typeof i3.PageRouterOutlet, typeof i4.NSEmptyOutletComponent], [typeof i5.RouterModule, typeof i6.NativeScriptCommonModule], [typeof i5.RouterModule, typeof i1.NSRouterLink, typeof i2.NSRouterLinkActive, typeof i3.PageRouterOutlet, typeof i4.NSEmptyOutletComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeScriptRouterModule>;
}
