import { NSLocationStrategy } from './ns-location-strategy';
import { PlatformLocation, LocationChangeListener } from '@angular/common';
import * as i0 from "@angular/core";
export declare class NativescriptPlatformLocation extends PlatformLocation {
    private locationStrategy;
    constructor(locationStrategy: NSLocationStrategy);
    getState(): any;
    readonly hostname: string;
    readonly href: string;
    readonly port: string;
    readonly protocol: string;
    getBaseHrefFromDOM(): string;
    onPopState(fn: LocationChangeListener): VoidFunction;
    onHashChange(_fn: LocationChangeListener): VoidFunction;
    get search(): string;
    get hash(): string;
    get pathname(): string;
    set pathname(_newPath: string);
    pushState(state: any, title: string, url: string): void;
    replaceState(state: any, title: string, url: string): void;
    forward(): void;
    back(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NativescriptPlatformLocation, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NativescriptPlatformLocation>;
}
