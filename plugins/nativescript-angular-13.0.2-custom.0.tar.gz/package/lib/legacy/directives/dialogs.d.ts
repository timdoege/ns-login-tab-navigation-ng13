import { ApplicationRef, ComponentFactoryResolver, Injector, NgModuleRef, NgZone, Type, ViewContainerRef } from '@angular/core';
import { ShowModalOptions, View, ViewBase } from '@nativescript/core';
import { NSLocationStrategy } from '../router/ns-location-strategy';
import * as i0 from "@angular/core";
export declare type BaseShowModalOptions = Pick<ShowModalOptions, Exclude<keyof ShowModalOptions, 'closeCallback' | 'context'>>;
export interface ModalDialogOptions extends BaseShowModalOptions {
    context?: any;
    viewContainerRef?: ViewContainerRef;
    moduleRef?: NgModuleRef<any>;
    target?: View;
}
export interface ShowDialogOptions extends BaseShowModalOptions {
    containerRef?: ViewContainerRef;
    /**
     * which container to attach the change detection
     * if not specified, attaches to the ApplicationRef (recommended)
     */
    attachToContainerRef?: ViewContainerRef;
    injector: Injector;
    context: any;
    doneCallback: any;
    pageFactory?: any;
    parentView: ViewBase;
    resolver: ComponentFactoryResolver;
    type: Type<any>;
}
export declare class ModalDialogParams {
    context: any;
    closeCallback: (...args: any[]) => any;
    constructor(context: any, closeCallback: (...args: any[]) => any);
}
export declare class ModalDialogService {
    private location;
    private zone;
    private appRef;
    private defaultInjector;
    constructor(location: NSLocationStrategy, zone: NgZone, appRef: ApplicationRef, defaultInjector: Injector);
    showModal(type: Type<any>, options?: ModalDialogOptions): Promise<any>;
    private _showDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModalDialogService>;
}
