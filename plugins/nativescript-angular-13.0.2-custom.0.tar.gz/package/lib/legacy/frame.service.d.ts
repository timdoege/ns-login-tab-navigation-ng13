import { Frame } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare class FrameService {
    getFrame(): Frame;
    static ɵfac: i0.ɵɵFactoryDeclaration<FrameService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FrameService>;
}
