/**
 * Utility method to ensure a NgModule is only imported once in a codebase, otherwise will throw to help prevent accidental double importing
 * @param parentModule Parent module name
 * @param moduleName The module name
 */
export declare function throwIfAlreadyLoaded(parentModule: any, moduleName: string): void;
/**
 * Utility method which will only fire the callback once ever
 * @param fn callback to call only once
 */
export declare function once(fn: Function): () => void;
/** Interface that can be used to generically type a class. */
export interface ComponentType<T> {
    new (...args: any[]): T;
}
