import { InjectionToken } from '@angular/core';
import { IDevice, Page, View } from '@nativescript/core';
export declare const APP_ROOT_VIEW: InjectionToken<View>;
export declare const NATIVESCRIPT_ROOT_MODULE_ID: InjectionToken<string | number>;
export declare const START_PATH: InjectionToken<string | Promise<string>>;
export declare const ENABLE_REUSABE_VIEWS: InjectionToken<boolean>;
export declare type PageFactory = (options: PageFactoryOptions) => Page;
export interface PageFactoryOptions {
    isBootstrap?: boolean;
    isLivesync?: boolean;
    isModal?: boolean;
    isNavigation?: boolean;
    componentType?: any;
}
export declare const DISABLE_ROOT_VIEW_HANDLING: InjectionToken<boolean>;
export declare const DEVICE: InjectionToken<IDevice>;
export declare const PAGE_FACTORY: InjectionToken<PageFactory>;
export declare const defaultPageFactory: PageFactory;
