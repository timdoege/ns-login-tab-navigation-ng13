import { NgZone } from '@angular/core';
import { AnimationDriver, ɵAnimationStyleNormalizer as AnimationStyleNormalizer, ɵWebAnimationsStyleNormalizer as WebAnimationsStyleNormalizer, ɵAnimationEngine as AnimationEngine } from '@angular/animations/browser';
import { ɵAnimationRendererFactory as AnimationRendererFactory } from '@angular/platform-browser/animations';
import { NativeScriptRendererFactory } from '../nativescript-renderer';
import { NativeScriptAnimationDriver } from './animation-driver';
import * as i0 from "@angular/core";
import * as i1 from "../nativescript-common.module";
export declare class InjectableAnimationEngine extends AnimationEngine {
    constructor(doc: any, driver: AnimationDriver, normalizer: AnimationStyleNormalizer);
    static ɵfac: i0.ɵɵFactoryDeclaration<InjectableAnimationEngine, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InjectableAnimationEngine>;
}
export declare function instantiateSupportedAnimationDriver(): NativeScriptAnimationDriver;
export declare function instantiateRendererFactory(renderer: NativeScriptRendererFactory, engine: AnimationEngine, zone: NgZone): AnimationRendererFactory;
export declare function instantiateDefaultStyleNormalizer(): WebAnimationsStyleNormalizer;
export declare class NativeScriptAnimationsModule {
    constructor(parentModule: NativeScriptAnimationsModule);
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptAnimationsModule, [{ optional: true; skipSelf: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeScriptAnimationsModule, never, [typeof i1.NativeScriptCommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeScriptAnimationsModule>;
}
