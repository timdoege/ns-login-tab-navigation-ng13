import * as i0 from "@angular/core";
import * as i1 from "./cdk/action-bar/index";
import * as i2 from "./cdk/list-view/list-view.component";
import * as i3 from "./cdk/tab-view/index";
import * as i4 from "./cdk/platform-filters/android-filter.component";
import * as i5 from "./cdk/platform-filters/ios-filter.component";
import * as i6 from "@angular/common";
import * as i7 from "./cdk/frame-page/frame-page.module";
export declare class NativeScriptCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeScriptCommonModule, [typeof i1.ActionBarComponent, typeof i1.ActionBarScope, typeof i1.ActionItemDirective, typeof i1.NavigationButtonDirective, typeof i2.ListViewComponent, typeof i2.TemplateKeyDirective, typeof i3.TabViewDirective, typeof i3.TabViewItemDirective, typeof i4.AndroidFilterComponent, typeof i5.IOSFilterComponent], [typeof i6.CommonModule, typeof i7.FramePageModule], [typeof i6.CommonModule, typeof i7.FramePageModule, typeof i1.ActionBarComponent, typeof i1.ActionBarScope, typeof i1.ActionItemDirective, typeof i1.NavigationButtonDirective, typeof i2.ListViewComponent, typeof i2.TemplateKeyDirective, typeof i3.TabViewDirective, typeof i3.TabViewItemDirective, typeof i4.AndroidFilterComponent, typeof i5.IOSFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeScriptCommonModule>;
}
