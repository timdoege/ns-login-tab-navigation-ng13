import { ComponentFactoryResolver, ComponentRef, Injector, TemplateRef, Type, ViewContainerRef } from '@angular/core';
import { DetachedLoader } from './cdk/detached-loader';
import { NgViewRef } from './view-refs';
/**
 * creates a DetachedLoader either linked to the ViewContainerRef or the ApplicationRef if ViewContainerRef is not defined
 * @param resolver component factory resolver
 * @param injector default injector, unused if viewContainerRef is set
 * @param viewContainerRef where the view should live in the angular tree
 * @returns reference to the DetachedLoader
 */
export declare function generateDetachedLoader(resolver: ComponentFactoryResolver, injector: Injector, viewContainerRef?: ViewContainerRef): ComponentRef<DetachedLoader>;
/**
 * Generates a NgViewRef from a component or template. @see NgViewRef
 * Pass keepNativeViewAttached as `true` if you don't want the first native view to be detached from its parent.
 * For opening modals and others, the firstNativeLikeView should be detached.
 * @param typeOrTemplate ComponentType or TemplateRef that should be instanced
 * @param options options for creating the view
 * @returns NgViewRef
 */
export declare function generateNativeScriptView<T>(typeOrTemplate: Type<T> | TemplateRef<T>, options: {
    resolver?: ComponentFactoryResolver;
    viewContainerRef?: ViewContainerRef;
    injector: Injector;
    keepNativeViewAttached?: boolean;
    /**
     * reuse a detachedLoaderRef. This will override viewContainerRef
     */
    detachedLoaderRef?: ComponentRef<DetachedLoader>;
}): NgViewRef<T>;
