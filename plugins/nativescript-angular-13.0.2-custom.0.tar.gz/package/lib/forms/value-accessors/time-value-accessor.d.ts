import { ElementRef } from '@angular/core';
import { TimePicker } from '@nativescript/core';
import { BaseValueAccessor } from './base-value-accessor';
import * as i0 from "@angular/core";
/**
 * The accessor for setting a time and listening to changes that is used by the
 * {@link NgModel} directives.
 *
 *  ### Example
 *  ```
 *  <TimePicker [(ngModel)]="model.test">
 *  ```
 */
export declare class TimeValueAccessor extends BaseValueAccessor<TimePicker> {
    constructor(elementRef: ElementRef);
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeValueAccessor, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TimeValueAccessor, "TimePicker[ngModel],TimePicker[formControlName],TimePicker[formControl],timepicker[ngModel],timepicker[formControlName],timepicker[formControl],timePicker[ngModel],timePicker[formControlName],timePicker[formControl],time-picker[ngModel],time-picker[formControlName],time-picker[formControl]", never, {}, {}, never>;
}
