import { ElementRef, AfterViewInit } from '@angular/core';
import { View } from '@nativescript/core';
import { BaseValueAccessor } from './base-value-accessor';
import * as i0 from "@angular/core";
export declare type SelectableView = {
    selectedIndex: number;
} & View;
/**
 * The accessor for setting a selectedIndex and listening to changes that is used by the
 * {@link NgModel} directives.
 *
 *  ### Example
 *  ```
 *  <SegmentedBar [(ngModel)]="model.test">
 *  ```
 */
export declare class SelectedIndexValueAccessor extends BaseValueAccessor<SelectableView> implements AfterViewInit {
    constructor(elementRef: ElementRef);
    private value;
    private viewInitialized;
    writeValue(value: any): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectedIndexValueAccessor, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SelectedIndexValueAccessor, "SegmentedBar[ngModel],SegmentedBar[formControlName],SegmentedBar[formControl],segmentedBar[ngModel],segmentedBar[formControlName],segmentedBar[formControl],segmentedbar[ngModel],segmentedbar[formControlName],segmentedbar[formControl],segmented-bar[ngModel],segmented-bar[formControlName],segmented-bar[formControl],ListPicker[ngModel],ListPicker[formControlName],ListPicker[formControl],listPicker[ngModel],listPicker[formControlName],listPicker[formControl],listpicker[ngModel],listpicker[formControlName],listpicker[formControl],list-picker[ngModel],list-picker[formControlName],list-picker[formControl],TabView[ngModel],TabView[formControlName],TabView[formControl],tabView[ngModel],tabView[formControlName],tabView[formControl],tabview[ngModel],tabview[formControlName],tabview[formControl],tab-view[ngModel],tab-view[formControlName],tab-view[formControl]", never, {}, {}, never>;
}
