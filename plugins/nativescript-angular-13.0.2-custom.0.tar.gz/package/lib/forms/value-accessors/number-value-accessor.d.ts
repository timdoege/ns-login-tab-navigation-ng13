import { ElementRef } from '@angular/core';
import { Slider } from '@nativescript/core';
import { BaseValueAccessor } from './base-value-accessor';
import * as i0 from "@angular/core";
/**
 * The accessor for setting a value and listening to changes that is used by the
 * {@link NgModel}
 *
 *  ### Example
 *  ```
 *  <Slider [(ngModel)]="model.test">
 *  ```
 */
export declare class NumberValueAccessor extends BaseValueAccessor<Slider> {
    constructor(elementRef: ElementRef);
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberValueAccessor, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NumberValueAccessor, "Slider[ngModel],Slider[formControlName],Slider[formControl],slider[ngModel],slider[formControlName],slider[formControl]", never, {}, {}, never>;
}
