import { ElementRef } from '@angular/core';
import { View } from '@nativescript/core';
import { BaseValueAccessor } from './base-value-accessor';
import * as i0 from "@angular/core";
export declare type TextView = {
    text: string;
} & View;
/**
 * The accessor for writing a text and listening to changes that is used by the
 * {@link NgModel} directives.
 *
 *  ### Example
 *  ```
 *  <TextField [(ngModel)]="model.test">
 *  ```
 */
export declare class TextValueAccessor extends BaseValueAccessor<TextView> {
    constructor(elementRef: ElementRef);
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextValueAccessor, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextValueAccessor, "TextField[ngModel],TextField[formControlName],TextField[formControl],textField[ngModel],textField[formControlName],textField[formControl],textfield[ngModel],textfield[formControlName],textfield[formControl],text-field[ngModel],text-field[formControlName],text-field[formControl],TextView[ngModel],TextView[formControlName],TextView[formControl],textView[ngModel],textView[formControlName],textView[formControl],textview[ngModel],textview[formControlName],textview[formControl],text-view[ngModel],text-view[formControlName],text-view[formControl],SearchBar[ngModel],SearchBar[formControlName],SearchBar[formControl],searchBar[ngModel],searchBar[formControlName],searchBar[formControl],searchbar[ngModel],searchbar[formControlName],searchbar[formControl],search-bar[ngModel], search-bar[formControlName],search-bar[formControl]", never, {}, {}, never>;
}
