import { ElementRef } from '@angular/core';
import { Switch } from '@nativescript/core';
import { BaseValueAccessor } from './base-value-accessor';
import * as i0 from "@angular/core";
/**
 * The accessor for setting a checked property and listening to changes that is used by the
 * {@link NgModel} directives.
 *
 *  ### Example
 *  ```
 *  <Switch [(ngModel)]="model.test">
 *  ```
 */
export declare class CheckedValueAccessor extends BaseValueAccessor<Switch> {
    constructor(elementRef: ElementRef);
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckedValueAccessor, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CheckedValueAccessor, "Switch[ngModel],Switch[formControlName],Switch[formControl],switch[ngModel],switch[formControlName],switch[formControl]", never, {}, {}, never>;
}
