import * as i0 from "@angular/core";
import * as i1 from "./value-accessors/text-value-accessor";
import * as i2 from "./value-accessors/checked-value-accessor";
import * as i3 from "./value-accessors/date-value-accessor";
import * as i4 from "./value-accessors/time-value-accessor";
import * as i5 from "./value-accessors/selectedIndex-value-accessor";
import * as i6 from "./value-accessors/number-value-accessor";
import * as i7 from "@angular/forms";
export * from './value-accessors';
export declare class NativeScriptFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeScriptFormsModule, [typeof i1.TextValueAccessor, typeof i2.CheckedValueAccessor, typeof i3.DateValueAccessor, typeof i4.TimeValueAccessor, typeof i5.SelectedIndexValueAccessor, typeof i6.NumberValueAccessor], [typeof i7.FormsModule], [typeof i7.FormsModule, typeof i1.TextValueAccessor, typeof i2.CheckedValueAccessor, typeof i3.DateValueAccessor, typeof i4.TimeValueAccessor, typeof i5.SelectedIndexValueAccessor, typeof i6.NumberValueAccessor]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeScriptFormsModule>;
}
