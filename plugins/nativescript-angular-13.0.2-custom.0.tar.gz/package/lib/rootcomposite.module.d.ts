import { ContentView, RootLayout, View } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare class RootViewProxy extends ContentView {
    private parentRootLayout;
    constructor(parentRootLayout: RootLayout);
    _addView(view: View, atIndex?: number): void;
    _removeView(view: View): void;
}
/**
 * This generates a RootLayout and returns a RootViewProxy.
 * Setting RootViewProxy.content will add the view to the bottom of the RootLayout
 * Setting RootViewProxy.content = null will remove the view from the RootLayout
 * @returns RootViewProxy that will insert content into the start of the RootLayout
 */
export declare function generateRootLayoutAndProxy(): RootViewProxy;
export declare class RootCompositeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RootCompositeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RootCompositeModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RootCompositeModule>;
}
