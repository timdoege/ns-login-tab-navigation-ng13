import { NgModuleRef, PlatformRef } from '@angular/core';
import { LayoutBase } from '@nativescript/core';
import { Observable, Subject } from 'rxjs';
export interface AppLaunchView extends LayoutBase {
    startAnimation?: () => void;
    cleanup?: () => Promise<any>;
    __disable_root_view_handling?: boolean;
}
export declare function disableRootViewHanding(view: AppLaunchView): void;
export declare type NgModuleReason = 'hotreload' | 'applaunch' | 'appexit';
export declare type NgModuleEvent = {
    moduleType: 'main' | 'loading' | string;
    reference: NgModuleRef<unknown>;
    reason: NgModuleReason | string;
} | {
    moduleType: 'platform';
    reference: PlatformRef;
    reason: NgModuleReason | string;
};
export declare const preAngularDisposal$: Subject<NgModuleEvent>;
export declare const postAngularBootstrap$: Subject<NgModuleEvent>;
/**
 * @deprecated
 */
export declare const onBeforeLivesync: Observable<NgModuleRef<any>>;
/**
 * @deprecated
 */
export declare const onAfterLivesync: Observable<{
    moduleRef?: NgModuleRef<any>;
    error?: Error;
}>;
export interface AppRunOptions<T, K> {
    appModuleBootstrap: (reason: NgModuleReason) => Promise<NgModuleRef<T>>;
    loadingModule?: (reason: NgModuleReason) => Promise<NgModuleRef<K>>;
    launchView?: (reason: NgModuleReason) => AppLaunchView;
}
export declare function runNativeScriptAngularApp<T, K>(options: AppRunOptions<T, K>): void;
