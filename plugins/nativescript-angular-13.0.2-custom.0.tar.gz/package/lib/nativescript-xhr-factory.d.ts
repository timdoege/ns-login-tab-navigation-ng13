import { XhrFactory } from '@angular/common';
import * as i0 from "@angular/core";
export declare class NativescriptXhrFactory extends XhrFactory {
    build(): XMLHttpRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<NativescriptXhrFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NativescriptXhrFactory>;
}
