import { ContentView, View, GridLayout, Color } from '@nativescript/core';
export declare class AppHostView extends ContentView {
    private _ngAppRoot;
    private _content;
    private timeout;
    constructor(backgroundColor: Color);
    get ngAppRoot(): View;
    set ngAppRoot(value: View);
    get content(): View;
    set content(value: View);
    scheduleRootChange(): void;
}
export declare class AppHostAsyncView extends GridLayout {
    constructor(backgroundColor: Color);
    get ngAppRoot(): View;
    set ngAppRoot(value: View);
}
