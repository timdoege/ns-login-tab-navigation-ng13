import { View } from '@nativescript/core';
import { CommentNode, NgView, TextNode } from './views';
import { NamespaceFilter } from './property-filter';
export declare type BeforeAttachAction = (view: View) => void;
export declare class ViewUtil {
    private namespaceFilters?;
    private reuseViews?;
    constructor(namespaceFilters?: NamespaceFilter[], reuseViews?: boolean);
    /**
     * Inserts a child into a parrent, preferably before next.
     * @param parent parent view
     * @param child child view to be added
     * @param previous previous element. If present, insert after this.
     * @param next next element. If present, insert before this (previous is ignored).
     */
    private insertChild;
    insertBefore(parent: View, child: View, refChild?: View | NgView): void;
    insertAfter(parent: View, child: View, refChild?: View | NgView): void;
    appendChild(parent: View, child: View): void;
    /**
     * Inserts a view into the parent/sibling linked list
     * !WARNING: this method makes no checks to validate the integrity of previous/next children
     * @param parent parent view
     * @param child child view
     * @param previous previous element. null/undefined for first element
     * @param next next element. null/undefined for last element
     */
    private insertInList;
    private addToVisualTree;
    private insertToLayout;
    private findNextVisual;
    removeChild(parent: View, child: View): void;
    private removeFromList;
    private findPreviousElement;
    private getPreviousVisualElement;
    getChildIndex(parent: any, child: NgView): number;
    private removeFromVisualTree;
    private removeLayoutChild;
    createComment(value: string): CommentNode;
    createText(value: string): TextNode;
    createView(name: string): NgView;
    private ensureNgViewExtensions;
    private setNgViewExtensions;
    setProperty(view: NgView, attributeName: string, value: any, namespace?: string): void;
    private runsIn;
    private setPropertyInternal;
    private removeParentReferencesFromItems;
    private getProperties;
    private cssClasses;
    addClass(view: View | NgView, className: string): void;
    removeClass(view: View, className: string): void;
    private setClasses;
    private syncClasses;
    setStyle(view: View, styleName: string, value: any): void;
    removeStyle(view: View, styleName: string): void;
}
