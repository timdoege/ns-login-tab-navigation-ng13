import { InjectionToken } from '@angular/core';
import { Device } from '@nativescript/core';
export interface NamespaceFilter {
    runsIn(namespace: string, next: (namespace: string) => boolean | undefined): boolean | undefined;
}
export declare class PlatformNamespaceFilter implements NamespaceFilter {
    private device;
    constructor(device: typeof Device);
    runsIn(namespace: string, next: (namespace: string) => boolean | undefined): boolean | undefined;
}
export declare const NAMESPACE_FILTERS: InjectionToken<NamespaceFilter[]>;
