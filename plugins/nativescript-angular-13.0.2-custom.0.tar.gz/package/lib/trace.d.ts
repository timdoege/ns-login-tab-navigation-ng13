export declare class NativeScriptDebug {
    static readonly animationsTraceCategory = "ns-animations";
    static readonly rendererTraceCategory = "ns-renderer";
    static readonly viewUtilCategory = "ns-view-util";
    static readonly routerTraceCategory = "ns-router";
    static readonly routeReuseStrategyTraceCategory = "ns-route-reuse-strategy";
    static readonly listViewTraceCategory = "ns-list-view";
    static readonly bootstrapCategory = "bootstrap";
    static readonly enabled: boolean;
    static isLogEnabled(): boolean;
    static animationsLog(message: string): void;
    static rendererLog(msg: any): void;
    static rendererError(message: string): void;
    static viewUtilLog(msg: any): void;
    static routerLog(message: string): void;
    static routerError(message: string): void;
    static routeReuseStrategyLog(message: string): void;
    static styleError(message: string): void;
    static listViewLog(message: string): void;
    static listViewError(message: string): void;
    static bootstrapLog(message: string): void;
    static bootstrapLogError(message: string): void;
}
