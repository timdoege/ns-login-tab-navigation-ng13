import { Renderer2, RendererFactory2, RendererStyleFlags2, RendererType2 } from '@angular/core';
import { View } from '@nativescript/core';
import { NgView } from './views';
import { NamespaceFilter } from './property-filter';
import * as i0 from "@angular/core";
export declare class NativeScriptRendererFactory implements RendererFactory2 {
    private rootView;
    private namespaceFilters;
    private rootModuleID;
    private reuseViews;
    private componentRenderers;
    private defaultRenderer;
    private viewUtil;
    constructor(rootView: View, namespaceFilters: NamespaceFilter[], rootModuleID: string | number, reuseViews: any);
    createRenderer(hostElement: any, type: RendererType2): Renderer2;
    whenRenderingDone(): Promise<any>;
}
declare class NativeScriptRenderer implements Renderer2 {
    private rootView;
    private namespaceFilters?;
    private reuseViews?;
    private viewUtil;
    constructor(rootView: View, namespaceFilters?: NamespaceFilter[], reuseViews?: boolean);
    get data(): {
        [key: string]: any;
    };
    destroy(): void;
    createElement(name: string, namespace?: string): NgView;
    createComment(value: string): import("./views").CommentNode;
    createText(value: string): import("./views").TextNode;
    destroyNode: (node: any) => void;
    appendChild(parent: View, newChild: View): void;
    insertBefore(parent: any, newChild: any, refChild: any): void;
    removeChild(parent: any, oldChild: any, isHostElement?: boolean): void;
    selectRootElement(selectorOrNode: any, preserveContent?: boolean): View;
    parentNode(node: NgView): import("@nativescript/core").ViewBase & View & import("./views").ViewExtensions;
    nextSibling(node: NgView): NgView;
    setAttribute(el: any, name: string, value: string, namespace?: string): void;
    removeAttribute(el: any, name: string, namespace?: string): void;
    addClass(el: any, name: string): void;
    removeClass(el: any, name: string): void;
    setStyle(el: any, style: string, value: any, flags?: RendererStyleFlags2): void;
    removeStyle(el: any, style: string, flags?: RendererStyleFlags2): void;
    setProperty(el: any, name: string, value: any): void;
    setValue(node: any, value: string): void;
    listen(target: View, eventName: string, callback: (event: any) => boolean | void): () => void;
}
export declare const COMPONENT_VARIABLE = "%COMP%";
export declare const HOST_ATTR: string;
export declare const CONTENT_ATTR: string;
export declare class EmulatedRenderer extends NativeScriptRenderer {
    private rootModuleId;
    private contentAttr;
    private hostAttr;
    constructor(component: RendererType2, rootView: View, namespaceFilters: NamespaceFilter[], rootModuleId: string | number, reuseViews: boolean);
    applyToHost(view: NgView): void;
    appendChild(parent: any, newChild: NgView): void;
    createElement(parent: any, name: string): NgView;
    private addStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmulatedRenderer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EmulatedRenderer>;
}
export {};
