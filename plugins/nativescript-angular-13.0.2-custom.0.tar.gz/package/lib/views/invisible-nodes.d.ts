import { View } from '@nativescript/core';
import { NgView } from './view-types';
export declare abstract class InvisibleNode extends View implements NgView {
    protected name: string;
    meta: {
        skipAddToDom: boolean;
    };
    nodeType: number;
    nodeName: string;
    parentNode: NgView;
    nextSibling: NgView;
    previousSibling: NgView;
    firstChild: NgView;
    lastChild: NgView;
    ngCssClasses: Map<string, boolean>;
    constructor(name?: string);
    toString(): string;
}
export declare class CommentNode extends InvisibleNode {
    protected static id: number;
    constructor(value?: string);
}
export declare class TextNode extends InvisibleNode {
    protected static id: number;
    constructor(value?: string);
}
