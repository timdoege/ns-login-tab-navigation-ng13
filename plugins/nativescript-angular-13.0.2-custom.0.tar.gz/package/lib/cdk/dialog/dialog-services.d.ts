/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { InjectionToken, Injector, OnDestroy, TemplateRef, Type } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { NSLocationStrategy } from '../../legacy/router/ns-location-strategy';
import { ComponentType } from '../../utils/general';
import { NativeDialogConfig } from './dialog-config';
import { NativeDialogRef } from './dialog-ref';
import { NativeModalRef } from './native-modal-ref';
import * as i0 from "@angular/core";
/** Injection token that can be used to access the data that was passed in to a dialog. */
export declare const NATIVE_DIALOG_DATA: InjectionToken<any>;
/** Injection token that can be used to specify default dialog options. */
export declare const NATIVE_DIALOG_DEFAULT_OPTIONS: InjectionToken<NativeDialogConfig<any>>;
/**
 * Base class for dialog services. The base dialog service allows
 * for arbitrary dialog refs and dialog container components.
 */
export declare abstract class _NativeDialogBase<C extends NativeModalRef> implements OnDestroy {
    private _injector;
    private _defaultOptions;
    private _parentDialog;
    private _dialogRefConstructor;
    private _nativeModalType;
    private _dialogDataToken;
    private locationStrategy;
    private _openDialogsAtThisLevel;
    private readonly _afterAllClosedAtThisLevel;
    private readonly _afterOpenedAtThisLevel;
    /**
     * Stream that emits when all open dialog have finished closing.
     * Will emit on subscribe if there are no open dialogs to begin with.
     */
    readonly afterAllClosed: Observable<void>;
    /** Keeps track of the currently-open dialogs. */
    get openDialogs(): NativeDialogRef<any>[];
    /** Stream that emits when a dialog has been opened. */
    get afterOpened(): Subject<NativeDialogRef<any>>;
    _getAfterAllClosed(): Subject<void>;
    constructor(_injector: Injector, _defaultOptions: NativeDialogConfig | undefined, _parentDialog: _NativeDialogBase<C> | undefined, _dialogRefConstructor: Type<NativeDialogRef<any>>, _nativeModalType: Type<C>, _dialogDataToken: InjectionToken<any>, locationStrategy: NSLocationStrategy);
    /**
     * Opens a modal dialog containing the given component.
     * @param component Type of the component to load into the dialog.
     * @param config Extra configuration options.
     * @returns Reference to the newly-opened dialog.
     */
    open<T, D = any, R = any>(component: ComponentType<T>, config?: NativeDialogConfig<D>): NativeDialogRef<T, R>;
    /**
     * Opens a modal dialog containing the given template.
     * @param template TemplateRef to instantiate as the dialog content.
     * @param config Extra configuration options.
     * @returns Reference to the newly-opened dialog.
     */
    open<T, D = any, R = any>(template: TemplateRef<T>, config?: NativeDialogConfig<D>): NativeDialogRef<T, R>;
    open<T, D = any, R = any>(template: ComponentType<T> | TemplateRef<T>, config?: NativeDialogConfig<D>): NativeDialogRef<T, R>;
    /**
     * Closes all of the currently-open dialogs.
     */
    closeAll(): void;
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById(id: string): NativeDialogRef<any> | undefined;
    ngOnDestroy(): void;
    /**
     * Attaches the user-provided component to the already-created dialog container.
     * @param componentOrTemplateRef The type of component being loaded into the dialog,
     *     or a TemplateRef to instantiate as the content.
     * @param dialogContainer Reference to the wrapping dialog container.
     * @param overlayRef Reference to the overlay in which the dialog resides.
     * @param config The dialog configuration.
     * @returns A promise resolving to the MatDialogRef that should be returned to the user.
     */
    private _attachDialogContent;
    /**
     * Creates a custom injector to be used inside the dialog. This allows a component loaded inside
     * of a dialog to close itself and, optionally, to return a value.
     * @param config Config object that is used to construct the dialog.
     * @param dialogRef Reference to the dialog.
     * @param dialogContainer Dialog container element that wraps all of the contents.
     * @returns The custom injector that can be used inside the dialog.
     */
    private _createInjector;
    /**
     * Removes a dialog from the array of open dialogs.
     * @param dialogRef Dialog to be removed.
     */
    private _removeOpenDialog;
    /** Closes all of the dialogs in an array. */
    private _closeDialogs;
    static ɵfac: i0.ɵɵFactoryDeclaration<_NativeDialogBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_NativeDialogBase<any>, never, never, {}, {}, never>;
}
/**
 * Service to open Material Design modal dialogs.
 */
export declare class NativeDialogService extends _NativeDialogBase<NativeModalRef> {
    constructor(injector: Injector, defaultOptions: NativeDialogConfig, parentDialog: NativeDialogService, location: NSLocationStrategy);
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeDialogService, [null, { optional: true; }, { optional: true; skipSelf: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NativeDialogService>;
}
