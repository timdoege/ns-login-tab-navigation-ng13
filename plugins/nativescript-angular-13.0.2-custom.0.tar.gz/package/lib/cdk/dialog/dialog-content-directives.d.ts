/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { OnChanges, OnInit, SimpleChanges, ElementRef } from '@angular/core';
import { View } from '@nativescript/core';
import { NativeDialogService } from './dialog-services';
import { NativeDialogRef } from './dialog-ref';
import * as i0 from "@angular/core";
/**
 * Button that will close the current dialog.
 */
export declare class NativeDialogCloseDirective implements OnInit, OnChanges {
    dialogRef: NativeDialogRef<any>;
    private _elementRef;
    private _dialog;
    /** Dialog close input. */
    dialogResult: any;
    _matDialogClose: any;
    constructor(dialogRef: NativeDialogRef<any>, _elementRef: ElementRef<View>, _dialog: NativeDialogService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    _onButtonClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeDialogCloseDirective, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NativeDialogCloseDirective, "[native-dialog-close], [nativeDialogClose]", ["nativeDialogClose"], { "dialogResult": "native-dialog-close"; "_matDialogClose": "nativeDialogClose"; }, {}, never>;
}
