import * as i0 from "@angular/core";
import * as i1 from "./dialog-content-directives";
export declare class NativeDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeDialogModule, [typeof i1.NativeDialogCloseDirective], never, [typeof i1.NativeDialogCloseDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeDialogModule>;
}
