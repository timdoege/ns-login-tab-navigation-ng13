import { ComponentRef, EmbeddedViewRef, Injector, ViewContainerRef } from '@angular/core';
import { View } from '@nativescript/core';
import { Subject } from 'rxjs';
import { NSLocationStrategy } from '../../legacy/router/ns-location-strategy';
import { DetachedLoader } from '../detached-loader';
import { ComponentPortal, TemplatePortal } from '../portal/common';
import { NativeScriptDomPortalOutlet } from '../portal/nsdom-portal-outlet';
import { NativeDialogConfig } from './dialog-config';
import { NgViewRef } from '../../view-refs';
export declare class NativeModalRef {
    private _config;
    private _injector;
    private location?;
    _id: string;
    stateChanged: Subject<{
        state: 'opened' | 'closed' | 'closing';
    }>;
    onDismiss: Subject<void>;
    parentView: View;
    portalOutlet: NativeScriptDomPortalOutlet;
    detachedLoaderRef: ComponentRef<DetachedLoader>;
    modalViewRef: NgViewRef<any>;
    private _closeCallback;
    constructor(_config: NativeDialogConfig, _injector: Injector, location?: NSLocationStrategy);
    _generateDetachedContainer(vcRef?: ViewContainerRef): void;
    attachTemplatePortal<T>(portal: TemplatePortal<T>): EmbeddedViewRef<T>;
    attachComponentPortal<T>(portal: ComponentPortal<T>): ComponentRef<T>;
    _startExitAnimation(): void;
    dispose(): void;
    private startModalNavigation;
}
