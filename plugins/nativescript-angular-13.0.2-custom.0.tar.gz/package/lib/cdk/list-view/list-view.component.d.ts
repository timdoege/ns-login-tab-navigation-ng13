import { AfterContentInit, DoCheck, ElementRef, EmbeddedViewRef, EventEmitter, InjectionToken, IterableDiffer, IterableDiffers, NgZone, OnDestroy, TemplateRef, ViewContainerRef } from '@angular/core';
import { ItemEventData, ListView, ObservableArray, View } from '@nativescript/core';
import { NgViewTemplate } from '../../view-refs';
import * as i0 from "@angular/core";
export interface TemplatedItemsHost<T = any> {
    registerTemplate(key: string, template: TemplateRef<T>): any;
}
export declare const TEMPLATED_ITEMS_COMPONENT: InjectionToken<TemplatedItemsHost<any>>;
export declare class ItemContext<T> {
    $implicit?: T;
    item?: T;
    index?: number;
    even?: boolean;
    odd?: boolean;
    constructor($implicit?: T, item?: T, index?: number, even?: boolean, odd?: boolean);
}
export declare class NsTemplatedItem<T> implements NgViewTemplate<{
    index: number;
    data: T;
}> {
    private template;
    location: ViewContainerRef;
    private onCreate?;
    constructor(template: TemplateRef<ItemContext<T>>, location: ViewContainerRef, onCreate?: (view: View) => void);
    create(context?: {
        index: number;
        data: T;
    }): View;
    update(view: View, context?: {
        index: number;
        data: T;
    }): void;
    attach(view: View): void;
    detach(view: View): void;
    dispose(view: View): void;
    getEmbeddedViewRef(view: View): EmbeddedViewRef<ItemContext<T>> | undefined;
    isValid(view: View): boolean;
    private setupItemContext;
}
export interface SetupItemViewArgs<T> {
    view: EmbeddedViewRef<ItemContext<T>>;
    nativeElement: View;
    data: T;
    index: number;
    context: ItemContext<T>;
}
export declare class ListViewComponent<T = any> implements DoCheck, OnDestroy, AfterContentInit, TemplatedItemsHost {
    private _iterableDiffers;
    private zone;
    get nativeElement(): ListView;
    protected templatedItemsView: ListView;
    protected _items: T[] | ObservableArray<T>;
    protected _differ: IterableDiffer<T>;
    protected _templateMap: Map<string, NsTemplatedItem<T>>;
    protected _viewToTemplate: WeakMap<View, string>;
    loader: ViewContainerRef;
    setupItemView: EventEmitter<SetupItemViewArgs<T>>;
    itemTemplateQuery: TemplateRef<ItemContext<T>>;
    fallbackItemTemplate: TemplateRef<ItemContext<T>>;
    get items(): T[] | ObservableArray<T>;
    set items(value: T[] | ObservableArray<T>);
    constructor(_elementRef: ElementRef, _iterableDiffers: IterableDiffers, zone: NgZone);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private setItemTemplates;
    registerTemplate(key: string, template: TemplateRef<ItemContext<T>>): void;
    onItemLoading(args: ItemEventData): void;
    setupViewRef(viewRef: EmbeddedViewRef<ItemContext<T>>, data: T, index: number, nativeElement: View): void;
    ngDoCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListViewComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListViewComponent<any>, "ListView", never, { "items": "items"; }, { "setupItemView": "setupItemView"; }, ["itemTemplateQuery"], never>;
}
export declare type RootLocator = (nodes: Array<unknown>, nestLevel: number) => View;
export declare function getItemViewRoot(viewRef: EmbeddedViewRef<unknown>, rootLocator?: RootLocator): View;
export declare class TemplateKeyDirective<T> {
    private templateRef;
    private comp;
    constructor(templateRef: TemplateRef<T>, comp: TemplatedItemsHost<T>);
    set nsTemplateKey(value: string);
    set nsTemplateKeys(values: string[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<TemplateKeyDirective<any>, [null, { host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TemplateKeyDirective<any>, "[nsTemplateKey],[nsTemplateKeys]", never, { "nsTemplateKey": "nsTemplateKey"; "nsTemplateKeys": "nsTemplateKeys"; }, {}, never>;
}
