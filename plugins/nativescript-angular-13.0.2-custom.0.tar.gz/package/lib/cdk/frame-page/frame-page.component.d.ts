import { AfterViewInit, ElementRef, OnChanges, Renderer2, SimpleChanges } from '@angular/core';
import { Frame, Page } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare function customFrameComponentFactory(v: FramePageComponent): Frame;
export declare function customPageFactoryFromFrame(v: FramePageComponent): Page;
export declare class FramePageComponent implements AfterViewInit, OnChanges {
    element: ElementRef<Frame>;
    page: Page;
    actionBarHidden: boolean;
    constructor(element: ElementRef<Frame>, renderer: Renderer2);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FramePageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FramePageComponent, "FramePage", never, { "actionBarHidden": "actionBarHidden"; }, {}, never, ["*"]>;
}
