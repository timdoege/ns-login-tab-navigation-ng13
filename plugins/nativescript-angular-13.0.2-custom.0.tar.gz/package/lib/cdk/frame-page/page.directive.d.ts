import { ElementRef } from '@angular/core';
import { Page } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare function customPageFactory(v: PageDirective): Page;
export declare class PageDirective {
    element: ElementRef<Page>;
    constructor(element: ElementRef<Page>);
    static ɵfac: i0.ɵɵFactoryDeclaration<PageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PageDirective, "Page", never, {}, {}, never>;
}
