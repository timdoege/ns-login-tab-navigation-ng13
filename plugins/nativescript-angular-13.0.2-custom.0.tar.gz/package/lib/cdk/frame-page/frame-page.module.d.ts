import * as i0 from "@angular/core";
import * as i1 from "./frame.directive";
import * as i2 from "./page.directive";
import * as i3 from "./frame-page.component";
export declare class FramePageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FramePageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FramePageModule, [typeof i1.FrameDirective, typeof i2.PageDirective, typeof i3.FramePageComponent], never, [typeof i1.FrameDirective, typeof i2.PageDirective, typeof i3.FramePageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FramePageModule>;
}
