import { ElementRef, OnDestroy } from '@angular/core';
import { NavigatedData, Page, ViewBase } from '@nativescript/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class PageService implements OnDestroy {
    page: Page;
    private _inPage$;
    private _pageEvents$;
    get inPage(): boolean;
    get inPage$(): Observable<boolean>;
    get pageEvents$(): Observable<NavigatedData>;
    constructor(page?: Page, elRef?: ElementRef<ViewBase>, view?: ViewBase);
    ngOnDestroy(): void;
    private pageEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageService, [{ optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageService>;
}
