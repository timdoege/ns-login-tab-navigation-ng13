import { ElementRef } from '@angular/core';
import { Frame } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare function customFrameDirectiveFactory(v: FrameDirective): Frame;
export declare class FrameDirective {
    element: ElementRef<Frame>;
    constructor(element: ElementRef<Frame>);
    static ɵfac: i0.ɵɵFactoryDeclaration<FrameDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FrameDirective, "Frame", never, {}, {}, never>;
}
