export * from './frame-page.component';
export * from './frame.directive';
export * from './page.directive';
export * from './page.service';
export { FramePageModule } from './frame-page.module';
