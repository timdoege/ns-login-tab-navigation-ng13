import { AfterViewInit, ElementRef, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { TabView } from '@nativescript/core';
import * as i0 from "@angular/core";
declare type TextTransform = 'initial' | 'none' | 'capitalize' | 'uppercase' | 'lowercase';
export interface TabViewItemDef {
    title?: string;
    iconSource?: string;
    textTransform?: TextTransform;
}
export declare class TabViewDirective implements AfterViewInit {
    tabView: TabView;
    private _selectedIndex;
    private viewInitialized;
    get selectedIndex(): number;
    set selectedIndex(value: number);
    constructor(element: ElementRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabViewDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabViewDirective, "TabView", never, { "selectedIndex": "selectedIndex"; }, {}, never>;
}
export declare class TabViewItemDirective implements OnInit {
    private owner;
    private templateRef;
    private viewContainer;
    private item;
    private _config;
    constructor(owner: TabViewDirective, templateRef: TemplateRef<any>, viewContainer: ViewContainerRef);
    set config(config: TabViewItemDef);
    get config(): TabViewItemDef;
    set title(title: string);
    get title(): string;
    set iconSource(iconSource: string);
    get iconSource(): string;
    set textTransform(textTransform: TextTransform);
    get textTransform(): TextTransform;
    private ensureItem;
    private applyConfig;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabViewItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabViewItemDirective, "[tabItem]", never, { "config": "tabItem"; "title": "title"; "iconSource": "iconSource"; "textTransform": "textTransform"; }, {}, never>;
}
export {};
