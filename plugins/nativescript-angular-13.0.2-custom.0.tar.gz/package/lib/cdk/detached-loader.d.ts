import { ComponentRef, ComponentFactory, ViewContainerRef, Type, ComponentFactoryResolver, ChangeDetectorRef, ApplicationRef, OnDestroy, TemplateRef, Injector } from '@angular/core';
import { ComponentPortal, TemplatePortal } from './portal';
import type { ComponentType } from '../utils/general';
import * as i0 from "@angular/core";
/**
 * Wrapper component used for loading components when navigating
 * It uses DetachedContainer as selector so that it is containerRef is not attached to
 * the visual tree.
 */
export declare class DetachedLoader implements OnDestroy {
    private resolver;
    private changeDetector;
    private containerRef;
    private appRef;
    vc: ViewContainerRef;
    private disposeFunctions;
    constructor(resolver: ComponentFactoryResolver, changeDetector: ChangeDetectorRef, containerRef: ViewContainerRef, appRef: ApplicationRef);
    createComponentPortal<T>(componentType: ComponentType<T>, customInjector?: Injector): ComponentPortal<T>;
    createTemplatePortal<T>(templateRef: TemplateRef<T>, context?: T): TemplatePortal<T>;
    private loadInLocation;
    ngOnDestroy(): void;
    detectChanges(): void;
    /**
     * @deprecated use Portals
     */
    loadComponent(componentType: Type<any>): Promise<ComponentRef<any>>;
    /**
     * @deprecated use Portals
     */
    loadComponentSync(componentType: Type<any>): ComponentRef<any>;
    /**
     * @deprecated use Portals
     */
    loadWithFactory<T>(factory: ComponentFactory<T>): ComponentRef<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetachedLoader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetachedLoader, "DetachedContainer", never, {}, {}, never, ["*"]>;
}
