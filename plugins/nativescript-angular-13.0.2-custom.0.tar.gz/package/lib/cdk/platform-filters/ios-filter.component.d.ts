import { IDevice } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare class IOSFilterComponent {
    show: boolean;
    constructor(device: IDevice);
    static ɵfac: i0.ɵɵFactoryDeclaration<IOSFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IOSFilterComponent, "ios", never, {}, {}, never, ["*"]>;
}
