import { IDevice } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare class AndroidFilterComponent {
    show: boolean;
    constructor(device: IDevice);
    static ɵfac: i0.ɵɵFactoryDeclaration<AndroidFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AndroidFilterComponent, "android", never, {}, {}, never, ["*"]>;
}
