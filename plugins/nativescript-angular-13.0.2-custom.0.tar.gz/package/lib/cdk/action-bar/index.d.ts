import { ElementRef, OnDestroy } from '@angular/core';
import { ActionItem, NavigationButton, Page } from '@nativescript/core';
import { ViewClassMeta } from '../../views/view-types';
import * as i0 from "@angular/core";
export declare function isActionItem(view: any): view is ActionItem;
export declare function isNavigationButton(view: any): view is NavigationButton;
export declare const actionBarMeta: ViewClassMeta;
export declare class ActionBarComponent {
    element: ElementRef;
    private page;
    constructor(element: ElementRef, page: Page);
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionBarComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionBarComponent, "ActionBar", never, {}, {}, never, ["*"]>;
}
export declare class ActionBarScope {
    private page;
    constructor(page: Page);
    onNavButtonInit(navBtn: NavigationButtonDirective): void;
    onNavButtonDestroy(navBtn: NavigationButtonDirective): void;
    onActionInit(item: ActionItemDirective): void;
    onActionDestroy(item: ActionItemDirective): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionBarScope, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionBarScope, "ActionBarExtension", never, {}, {}, never, never>;
}
export declare class ActionItemDirective implements OnDestroy {
    element: ElementRef;
    private ownerScope;
    constructor(element: ElementRef, ownerScope: ActionBarScope);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionItemDirective, [null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ActionItemDirective, "ActionItem", never, {}, {}, never>;
}
export declare class NavigationButtonDirective implements OnDestroy {
    element: ElementRef;
    private ownerScope;
    constructor(element: ElementRef, ownerScope: ActionBarScope);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationButtonDirective, [null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NavigationButtonDirective, "NavigationButton", never, {}, {}, never>;
}
