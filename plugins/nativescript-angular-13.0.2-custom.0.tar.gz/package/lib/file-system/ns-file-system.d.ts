import { Folder, File } from '@nativescript/core';
import * as i0 from "@angular/core";
export declare class NSFileSystem {
    currentApp(): Folder;
    fileFromPath(path: string): File;
    fileExists(path: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NSFileSystem, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NSFileSystem>;
}
