import { OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class NativeScriptLoadingService implements OnDestroy {
    private mainModuleReady$;
    readyToDestroy$: BehaviorSubject<boolean>;
    onMainModuleReady$: import("rxjs").Observable<boolean>;
    /**
     * delays destroying this module until `notifyReadyToDestroy()`.
     * remember to call `notifyReadyToDestroy()` when done!
     */
    waitUntilNotified(): void;
    /**
     * notifies this module is ready to be destroyed
     */
    notifyReadyToDestroy(): void;
    isMainModuleReady(): boolean;
    ngOnDestroy(): void;
    /**
     * This funcion is called by the bootstrap code when the app is ready
     * @internal
     */
    _notifyMainModuleReady(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptLoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NativeScriptLoadingService>;
}
