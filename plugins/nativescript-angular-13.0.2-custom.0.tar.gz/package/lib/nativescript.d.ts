import { ErrorHandler, Provider, StaticProvider } from '@angular/core';
import { View } from '@nativescript/core';
import * as i0 from "@angular/core";
import * as i1 from "./cdk/detached-loader";
import * as i2 from "./nativescript-common.module";
export declare function generateFallbackRootView(parentRootView?: View): View;
export declare function errorHandler(): ErrorHandler;
export declare function generateRandomId(): string;
export declare const NATIVESCRIPT_MODULE_STATIC_PROVIDERS: StaticProvider[];
export declare const NATIVESCRIPT_MODULE_PROVIDERS: Provider[];
export declare class NativeScriptModule {
    constructor(parentModule: NativeScriptModule | null);
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptModule, [{ optional: true; skipSelf: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NativeScriptModule, [typeof i1.DetachedLoader], [typeof i0.ApplicationModule, typeof i2.NativeScriptCommonModule], [typeof i0.ApplicationModule, typeof i1.DetachedLoader, typeof i2.NativeScriptCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NativeScriptModule>;
}
