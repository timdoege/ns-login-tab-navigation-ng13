export declare function registerNativeScriptViewComponents(): void;
