import { View } from '@nativescript/core';
import { ViewClassMeta } from '../views/view-types';
export declare type ViewResolver = () => any;
export declare const elementMap: Map<string, {
    resolver: ViewResolver;
    meta?: ViewClassMeta;
}>;
export declare function registerElement(elementName: string, resolver: ViewResolver, meta?: ViewClassMeta): void;
export declare function getViewClass(elementName: string): any;
export declare function getViewMeta(nodeName: string): ViewClassMeta;
export declare function isKnownView(elementName: string): boolean;
export declare function extractSingleViewRecursive(nodes: Array<any>, nestLevel: number): View;
/**
 * @deprecated getSingleViewRecursive is deprecated, use extractSingleViewRecursive
 */
export declare function getSingleViewRecursive(nodes: Array<any>, nestLevel: number): View;
