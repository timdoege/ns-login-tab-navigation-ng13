import { ViewClassMeta } from '../views/view-types';
export declare const frameMeta: ViewClassMeta;
