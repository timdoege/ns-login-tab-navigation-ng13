import { Type, PlatformRef, NgModuleFactory, Sanitizer, InjectionToken, StaticProvider } from '@angular/core';
import { NativeScriptPlatformRefProxy } from './platform-ref';
import { AppLaunchView } from './application';
export declare const defaultPageFactoryProvider: {
    provide: InjectionToken<import("./tokens").PageFactory>;
    useValue: import("./tokens").PageFactory;
};
export declare class NativeScriptSanitizer extends Sanitizer {
    sanitize(_context: any, value: string): string;
}
export declare class NativeScriptDocument {
    body: any;
    createElement(tag: string): void;
}
export declare const COMMON_PROVIDERS: ({
    provide: InjectionToken<import("./tokens").PageFactory>;
    useValue: import("./tokens").PageFactory;
} | {
    provide: typeof Sanitizer;
    useClass: typeof NativeScriptSanitizer;
    deps: any[];
} | {
    provide: InjectionToken<Document>;
    useClass: typeof NativeScriptDocument;
    deps: any[];
})[];
export declare const platformNativeScript: (extraProviders?: StaticProvider[]) => PlatformRef;
export interface HmrOptions {
    /**
     * A factory function that returns either Module type or NgModuleFactory type.
     * This needs to be a factory function as the types will change when modules are replaced.
     */
    moduleTypeFactory?: () => Type<any> | NgModuleFactory<any>;
    /**
     * A livesync callback that will be called instead of the original livesync.
     * It gives the HMR a hook to apply the module replacement.
     * @param bootstrapPlatform - A bootstrap callback to be called after HMR is done. It will bootstrap a new angular app within the exisiting platform, using the moduleTypeFactory to get the Module or NgModuleFactory to be used.
     */
    livesyncCallback: (bootstrapPlatform: () => void) => void;
}
export interface AppOptions {
    cssFile?: string;
    startPageActionBarHidden?: boolean;
    hmrOptions?: HmrOptions;
    /**
     * Background color of the root view
     */
    backgroundColor?: string;
    /**
     * Use animated launch view (async by default)
     */
    launchView?: AppLaunchView;
    /**
     * When using Async APP_INITIALIZER, set this to `true`.
     * (Not needed when using launchView)
     */
    async?: boolean;
}
/**
 * @deprecated use runNativeScriptAngularApp instead
 */
export declare const platformNativeScriptDynamic: (options?: AppOptions, extraProviders?: StaticProvider[]) => NativeScriptPlatformRefProxy;
