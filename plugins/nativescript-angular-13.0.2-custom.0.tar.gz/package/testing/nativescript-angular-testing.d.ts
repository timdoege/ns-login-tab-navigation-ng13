/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@nativescript/angular/testing" />
export * from './index';
