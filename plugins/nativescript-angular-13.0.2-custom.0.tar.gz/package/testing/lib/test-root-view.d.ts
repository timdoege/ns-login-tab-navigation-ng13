import { LayoutBase } from '@nativescript/core';
/**
 * Get a reference to the fixtures container.
 */
export declare function testingRootView(): LayoutBase;
