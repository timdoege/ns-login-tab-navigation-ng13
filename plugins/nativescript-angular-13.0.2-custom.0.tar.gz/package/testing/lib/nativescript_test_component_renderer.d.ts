import { TestComponentRenderer } from '@angular/core/testing';
import * as i0 from "@angular/core";
/**
 * A NativeScript based implementation of the TestComponentRenderer.
 */
export declare class NativeScriptTestComponentRenderer extends TestComponentRenderer {
    insertRootElement(rootElId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeScriptTestComponentRenderer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NativeScriptTestComponentRenderer>;
}
