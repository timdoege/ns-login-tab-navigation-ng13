import { Frame, GridLayout, ProxyViewContainer } from '@nativescript/core';
import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { TestComponentRenderer, TestBed } from '@angular/core/testing';
import { COMMON_PROVIDERS, APP_ROOT_VIEW, NativeScriptModule } from '@nativescript/angular';
import { platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';

const TESTING_ROOT_ID = '__testing_container';
/**
 * Get a reference to the fixtures container.
 */
function testingRootView() {
    const rootPageLayout = Frame.topmost().currentPage.content;
    let testingRoot;
    rootPageLayout.eachChild((child) => {
        if (child.id === TESTING_ROOT_ID) {
            testingRoot = child;
            // rootPageLayout.removeChild(child);
            return false;
        }
        return true;
    });
    if (!testingRoot) {
        testingRoot = new GridLayout();
        testingRoot.id = TESTING_ROOT_ID;
        GridLayout.setColumnSpan(testingRoot, 100);
        GridLayout.setRowSpan(testingRoot, 100);
        rootPageLayout.addChild(testingRoot);
    }
    return testingRoot;
}

/**
 * A NativeScript based implementation of the TestComponentRenderer.
 */
class NativeScriptTestComponentRenderer extends TestComponentRenderer {
    insertRootElement(rootElId) {
        const layout = new ProxyViewContainer();
        layout.id = rootElId;
        const rootLayout = testingRootView();
        while (rootLayout.getChildrenCount() > 0) {
            rootLayout.removeChild(rootLayout.getChildAt(0));
        }
        rootLayout.addChild(layout);
    }
}
NativeScriptTestComponentRenderer.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestComponentRenderer, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
NativeScriptTestComponentRenderer.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestComponentRenderer });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestComponentRenderer, decorators: [{
            type: Injectable
        }] });

if (typeof Node === 'undefined' && !global.Node) {
    class DummyNode {
    }
    global.Node = DummyNode;
}
/**
 * Providers array is exported for cases where a custom module has to be constructed
 * to test a particular piece of code. This can happen, for example, if you are trying
 * to test dynamic component loading and need to specify an entryComponent for the testing
 * module.
 */
const NATIVESCRIPT_TESTING_PROVIDERS = [...COMMON_PROVIDERS, { provide: APP_ROOT_VIEW, useFactory: testingRootView }, { provide: TestComponentRenderer, useClass: NativeScriptTestComponentRenderer }];
/**
 * NativeScript testing support module. Enables use of TestBed for angular components, directives,
 * pipes, and services.
 */
class NativeScriptTestingModule {
}
NativeScriptTestingModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
NativeScriptTestingModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestingModule, exports: [NativeScriptModule] });
NativeScriptTestingModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestingModule, providers: NATIVESCRIPT_TESTING_PROVIDERS, imports: [NativeScriptModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: NativeScriptTestingModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [NativeScriptModule],
                    providers: NATIVESCRIPT_TESTING_PROVIDERS,
                }]
        }] });

/**
 * Declared test contexts. When the suite is done this map should be empty if all lifecycle
 * calls have happened as expected.
 * @private
 */
const activeTestFixtures = [];
/**
 * Return a promise that resolves after (durationMs) milliseconds
 */
function promiseWait(durationMs) {
    return () => new Promise((resolve) => setTimeout(() => resolve(), durationMs));
}
/**
 * Perform basic TestBed environment initialization. Call this once in the main entry point to your tests.
 * @deprecated
 */
function nsTestBedInit() {
    TestBed.initTestEnvironment(NativeScriptTestingModule, platformBrowserDynamicTesting() // NS_COMPILER_PROVIDERS)
    );
}
/**
 * Helper for configuring a TestBed instance for rendering components for test. Ideally this
 * would not be needed, and in truth it's just a wrapper to eliminate some boilerplate. It
 * exists because when you need to specify `entryComponents` for a test the setup becomes quite
 * a bit more complex than if you're just doing a basic component test.
 *
 * More about entryComponents complexity: https://github.com/angular/angular/issues/12079
 *
 * Use:
 * ```
 *   beforeEach(nsTestBedBeforeEach([MyComponent,MyFailComponent]));
 * ```
 *
 * **NOTE*** Remember to pair with {@see nsTestBedAfterEach}
 *
 * @deprecated
 * @param components Any components that you will create during the test
 * @param providers Any services your tests depend on
 * @param imports Any module imports your tests depend on
 * @param entryComponents Any entry components that your tests depend on
 */
function nsTestBedBeforeEach(components, providers = [], imports = [], entryComponents = []) {
    return (done) => {
        activeTestFixtures.push([]);
        // If there are no entry components we can take the simple path.
        if (entryComponents.length === 0) {
            TestBed.configureTestingModule({
                declarations: [...components],
                providers: [...providers],
                imports: [NativeScriptModule, ...imports],
            });
        }
        else {
            // If there are entry components, we have to reset the testing platform.
            //
            // There's got to be a better way... (o_O)
            // TestBed.resetTestEnvironment();
            // @NgModule({
            //     declarations: entryComponents,
            //     exports: entryComponents,
            //     entryComponents: entryComponents
            // })
            // class EntryComponentsTestModule {
            // }
            // TestBed.initTestEnvironment(
            //     EntryComponentsTestModule,
            //     platformBrowserDynamicTesting(NS_COMPILER_PROVIDERS)
            // );
            // TestBed.configureTestingModule({
            //     declarations: components,
            //     imports: [
            //         NativeScriptModule, NativeScriptTestingModule, CommonModule,
            //         ...imports
            //     ],
            //     providers: [...providers, ...NATIVESCRIPT_TESTING_PROVIDERS],
            // });
        }
        TestBed.compileComponents()
            .then(() => done())
            .catch((e) => {
            console.log(`Failed to instantiate test component with error: ${e}`);
            console.log(e.stack);
            done();
        });
    };
}
/**
 * Helper for a basic component TestBed clean up.
 * @param resetEnv When true the testing environment will be reset
 * @param resetFn When resetting the environment, use this init function
 * @deprecated
 */
function nsTestBedAfterEach(resetEnv = true, resetFn = nsTestBedInit) {
    return () => {
        if (activeTestFixtures.length === 0) {
            throw new Error(`There are no more declared fixtures.` + `Did you call "nsTestBedBeforeEach" and "nsTestBedAfterEach" an equal number of times?`);
        }
        const root = testingRootView();
        const fixtures = activeTestFixtures.pop();
        fixtures.forEach((fixture) => {
            const fixtureView = fixture.nativeElement;
            if (fixtureView.parent === root) {
                root.removeChild(fixtureView);
            }
            fixture.destroy();
        });
        TestBed.resetTestingModule();
        if (resetEnv) {
            TestBed.resetTestEnvironment();
            resetFn();
        }
    };
}
/**
 * Render a component using the TestBed helper, and return a promise that resolves when the
 * ComponentFixture is fully initialized.
 * @deprecated
 */
function nsTestBedRender(componentType) {
    const fixture = TestBed.createComponent(componentType);
    fixture.detectChanges();
    return (fixture
        .whenRenderingDone()
        // TODO(jd): it seems that the whenStable and whenRenderingDone utilities of ComponentFixture
        //           do not work as expected. I looked at how to fix it and it's not clear how to provide
        //           a {N} specific subclass, because ComponentFixture is newed directly rather than injected
        // What to do about it? Maybe fakeAsync can help? For now just setTimeout for 100ms (x_X)
        .then(promiseWait(100))
        .then(() => {
        const list = activeTestFixtures[activeTestFixtures.length - 1];
        if (!list) {
            console.warn('nsTestBedRender called without nsTestBedBeforeEach/nsTestBedAfter each. ' + "You are responsible for calling 'fixture.destroy()' when your test is done " + 'in order to clean up the components that are created.');
        }
        else {
            list.push(fixture);
        }
        return fixture;
    }));
}

/**
 * Generated bundle index. Do not edit.
 */

export { NATIVESCRIPT_TESTING_PROVIDERS, NativeScriptTestComponentRenderer, NativeScriptTestingModule, nsTestBedAfterEach, nsTestBedBeforeEach, nsTestBedInit, nsTestBedRender, promiseWait, testingRootView };
//# sourceMappingURL=nativescript-angular-testing.mjs.map
