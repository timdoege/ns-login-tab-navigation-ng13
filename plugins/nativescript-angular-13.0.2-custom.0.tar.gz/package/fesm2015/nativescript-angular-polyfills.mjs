// placeholder for when we actually need some polyfills
const nsNgPolyfills = true;

/**
 * Generated bundle index. Do not edit.
 */

export { nsNgPolyfills };
//# sourceMappingURL=nativescript-angular-polyfills.mjs.map
