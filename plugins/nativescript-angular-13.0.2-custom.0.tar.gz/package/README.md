# @nativescript/angular

NativeScript for Angular v12+